export const locale = {
  lang: 'fr',
  data: {
    SAMPLE: {
      CONGRATULATIONS: 'Toutes nos félicitations',
      BADGE: "Vous avez remporté la médaille d'or"
    }
  }
};
