export const locale = {
  lang: 'pt',
  data: {
    SAMPLE: {
      CONGRATULATIONS: 'Parabéns',
      BADGE: 'Você ganhou medalha de ouro'
    }
  }
};
