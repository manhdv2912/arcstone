export const locale = {
  lang: 'en',
  data: {
    SAMPLE: {
      CONGRATULATIONS: 'Congratulations',
      BADGE: 'You have won gold medal'
    }
  }
};
