export const locale = {
  lang: 'de',
  data: {
    SAMPLE: {
      CONGRATULATIONS: 'Herzliche Glückwünsche',
      BADGE: 'Sie haben die Goldmedaille gewonnen'
    }
  }
};
