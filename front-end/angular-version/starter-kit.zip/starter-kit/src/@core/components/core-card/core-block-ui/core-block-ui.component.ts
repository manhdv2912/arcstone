import { Component } from '@angular/core';

@Component({
  selector: 'core-block-ui',
  templateUrl: './core-block-ui.component.html'
})
export class CoreBlockUiComponent {
  constructor() {}
}
